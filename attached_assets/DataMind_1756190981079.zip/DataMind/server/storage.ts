import { 
  type User, 
  type InsertUser, 
  type JobPost, 
  type InsertJobPost,
  type CareerArticle,
  type InsertCareerArticle,
  type Application,
  type InsertApplication,
  users,
  jobPosts,
  careerArticles,
  applications
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Job posts methods
  getJobPosts(): Promise<JobPost[]>;
  getJobPost(id: string): Promise<JobPost | undefined>;
  createJobPost(jobPost: InsertJobPost): Promise<JobPost>;
  
  // Career articles methods
  getCareerArticles(): Promise<CareerArticle[]>;
  getCareerArticle(id: string): Promise<CareerArticle | undefined>;
  getCareerArticleBySlug(slug: string): Promise<CareerArticle | undefined>;
  createCareerArticle(article: InsertCareerArticle): Promise<CareerArticle>;
  
  // Applications methods
  createApplication(application: InsertApplication): Promise<Application>;
  getApplications(): Promise<Application[]>;
  getApplication(id: string): Promise<Application | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getJobPosts(): Promise<JobPost[]> {
    return await db
      .select()
      .from(jobPosts)
      .where(eq(jobPosts.isActive, true))
      .orderBy(desc(jobPosts.createdAt));
  }

  async getJobPost(id: string): Promise<JobPost | undefined> {
    const [jobPost] = await db
      .select()
      .from(jobPosts)
      .where(eq(jobPosts.id, id));
    return jobPost || undefined;
  }

  async createJobPost(insertJobPost: InsertJobPost): Promise<JobPost> {
    const [jobPost] = await db
      .insert(jobPosts)
      .values(insertJobPost)
      .returning();
    return jobPost;
  }

  async getCareerArticles(): Promise<CareerArticle[]> {
    return await db
      .select()
      .from(careerArticles)
      .where(eq(careerArticles.isPublished, true))
      .orderBy(desc(careerArticles.createdAt));
  }

  async getCareerArticle(id: string): Promise<CareerArticle | undefined> {
    const [article] = await db
      .select()
      .from(careerArticles)
      .where(eq(careerArticles.id, id));
    return article || undefined;
  }

  async getCareerArticleBySlug(slug: string): Promise<CareerArticle | undefined> {
    const [article] = await db
      .select()
      .from(careerArticles)
      .where(eq(careerArticles.slug, slug));
    return article || undefined;
  }

  async createCareerArticle(insertArticle: InsertCareerArticle): Promise<CareerArticle> {
    const [article] = await db
      .insert(careerArticles)
      .values(insertArticle)
      .returning();
    return article;
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const [application] = await db
      .insert(applications)
      .values(insertApplication)
      .returning();
    return application;
  }

  async getApplications(): Promise<Application[]> {
    return await db
      .select()
      .from(applications)
      .orderBy(desc(applications.createdAt));
  }

  async getApplication(id: string): Promise<Application | undefined> {
    const [application] = await db
      .select()
      .from(applications)
      .where(eq(applications.id, id));
    return application || undefined;
  }
}

export const storage = new DatabaseStorage();
