import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertApplicationSchema, insertJobPostSchema, insertCareerArticleSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import { z } from "zod";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /pdf|doc|docx|jpg|jpeg|png/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Job posts routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getJobPosts();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job posts" });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const job = await storage.getJobPost(req.params.id);
      if (!job) {
        return res.status(404).json({ message: "Job post not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job post" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    try {
      const jobData = insertJobPostSchema.parse(req.body);
      const job = await storage.createJobPost(jobData);
      res.status(201).json(job);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid job data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create job post" });
    }
  });

  // Career articles routes
  app.get("/api/articles", async (req, res) => {
    try {
      const articles = await storage.getCareerArticles();
      res.json(articles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch career articles" });
    }
  });

  app.get("/api/articles/:slug", async (req, res) => {
    try {
      const article = await storage.getCareerArticleBySlug(req.params.slug);
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch article" });
    }
  });

  app.post("/api/articles", async (req, res) => {
    try {
      const articleData = insertCareerArticleSchema.parse(req.body);
      const article = await storage.createCareerArticle(articleData);
      res.status(201).json(article);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid article data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create article" });
    }
  });

  // Applications routes
  app.post("/api/applications", upload.fields([
    { name: 'resume', maxCount: 1 },
    { name: 'certificates', maxCount: 5 }
  ]), async (req, res) => {
    try {
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      const applicationData = {
        ...req.body,
        termsAccepted: req.body.termsAccepted === 'true',
        marketingConsent: req.body.marketingConsent === 'true',
        resumeUrl: files.resume?.[0]?.filename || null,
        certificatesUrls: files.certificates?.map(file => file.filename) || [],
      };

      const validatedData = insertApplicationSchema.parse(applicationData);
      const application = await storage.createApplication(validatedData);
      
      res.status(201).json({ 
        message: "Application submitted successfully",
        id: application.id 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid application data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit application" });
    }
  });

  app.get("/api/applications", async (req, res) => {
    try {
      const applications = await storage.getApplications();
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  // Seed sample data endpoint (for development)
  app.post("/api/seed-data", async (req, res) => {
    try {
      // Sample job posts
      const sampleJobs = [
        {
          title: "Senior Software Engineer",
          company: "TechCorp Solutions",
          location: "San Francisco, CA (Remote)",
          type: "Full-time",
          salary: "$120,000 - $160,000",
          description: "We're looking for an experienced software engineer to join our growing team. You'll work on cutting-edge projects using modern technologies and help shape the future of our platform.\n\nResponsibilities:\n• Design and develop scalable web applications\n• Collaborate with cross-functional teams\n• Mentor junior developers\n• Participate in code reviews and technical discussions",
          requirements: "5+ years of experience in software development\nProficiency in React, Node.js, and TypeScript\nExperience with cloud platforms (AWS, GCP, or Azure)\nStrong problem-solving and communication skills\nBachelor's degree in Computer Science or related field",
          skills: ["React", "Node.js", "TypeScript", "AWS", "PostgreSQL"],
          excerpt: "Join our team as a Senior Software Engineer and work on cutting-edge projects using modern technologies. Remote-friendly position with competitive salary and great benefits.",
          isActive: true
        },
        {
          title: "Digital Marketing Specialist",
          company: "GrowthHub Agency",
          location: "New York, NY",
          type: "Full-time",
          salary: "$65,000 - $85,000",
          description: "We're seeking a creative and data-driven Digital Marketing Specialist to help our clients achieve their growth goals. You'll manage campaigns across multiple channels and analyze performance metrics.\n\nKey Responsibilities:\n• Develop and execute digital marketing strategies\n• Manage social media accounts and content creation\n• Analyze campaign performance and optimize ROI\n• Coordinate with design and content teams",
          requirements: "3+ years of digital marketing experience\nProficiency in Google Analytics, Facebook Ads, and Google Ads\nExcellent written and verbal communication skills\nExperience with marketing automation tools\nBachelor's degree in Marketing or related field",
          skills: ["Digital Marketing", "Google Analytics", "Social Media", "SEO", "Content Strategy"],
          excerpt: "Drive growth for leading brands as our Digital Marketing Specialist. Work with cutting-edge tools and creative campaigns in a dynamic agency environment.",
          isActive: true
        },
        {
          title: "UX/UI Designer",
          company: "DesignStudio Pro",
          location: "Los Angeles, CA (Hybrid)",
          type: "Full-time",
          salary: "$80,000 - $110,000",
          description: "Join our creative team as a UX/UI Designer and help create beautiful, user-centered digital experiences. You'll work on diverse projects from mobile apps to enterprise software.\n\nWhat You'll Do:\n• Create wireframes, prototypes, and high-fidelity designs\n• Conduct user research and usability testing\n• Collaborate with developers and product managers\n• Maintain and evolve design systems",
          requirements: "4+ years of UX/UI design experience\nProficiency in Figma, Sketch, or Adobe Creative Suite\nStrong portfolio demonstrating design thinking\nExperience with user research methods\nUnderstanding of front-end development principles",
          skills: ["UX Design", "UI Design", "Figma", "User Research", "Prototyping"],
          excerpt: "Shape amazing user experiences as our UX/UI Designer. Work on diverse projects with a talented creative team in a collaborative, hybrid environment.",
          isActive: true
        }
      ];

      // Sample career articles
      const sampleArticles = [
        {
          title: "10 Essential Skills Every Software Developer Needs in 2024",
          slug: "essential-software-developer-skills-2024",
          excerpt: "Stay competitive in the ever-evolving tech industry with these crucial skills that every developer should master this year.",
          content: "The technology landscape continues to evolve at a rapid pace, and staying current with essential skills is crucial for career success. Here are the top 10 skills every software developer should focus on in 2024.\n\n1. Cloud Computing and DevOps\nCloud platforms like AWS, Azure, and Google Cloud have become fundamental to modern software development. Understanding containerization with Docker, orchestration with Kubernetes, and CI/CD pipelines will set you apart.\n\n2. AI and Machine Learning Integration\nWith the rise of AI tools and services, developers who can integrate machine learning models and work with AI APIs will be in high demand.\n\n3. Cybersecurity Awareness\nSecurity-first development practices are no longer optional. Understanding OWASP guidelines, secure coding practices, and threat modeling is essential.\n\n4. Full-Stack Development\nVersatility remains valuable. Being proficient in both frontend and backend technologies allows for better collaboration and career flexibility.\n\n5. Data Analysis and Visualization\nThe ability to work with data, create meaningful insights, and present them visually is increasingly important across all development roles.",
          category: "Skills",
          imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
          isPublished: true
        },
        {
          title: "Remote Work Best Practices: Staying Productive from Home",
          slug: "remote-work-best-practices-productivity",
          excerpt: "Master the art of remote work with proven strategies for maintaining productivity, work-life balance, and professional growth.",
          content: "Remote work has transformed from a luxury to a necessity for many professionals. Success in a remote environment requires intentional strategies and disciplined execution.\n\nCreating Your Ideal Workspace\nDedicate a specific area of your home to work. This physical boundary helps maintain the psychological separation between work and personal life. Invest in ergonomic furniture and proper lighting to support long work sessions.\n\nEstablishing Clear Boundaries\nSet specific work hours and communicate them to your household. Use visual cues like closing your office door or changing clothes to signal the start and end of your workday.\n\nMaintaining Communication\nOver-communicate with your team. Regular check-ins, clear status updates, and proactive communication help bridge the gap created by physical distance.\n\nFocusing on Results\nRemote work is results-oriented. Focus on deliverables and outcomes rather than hours worked. Set clear daily and weekly goals to stay on track.\n\nInvesting in Professional Development\nRemote work provides flexibility to invest in learning. Use commute time savings for online courses, certifications, or skill development.",
          category: "Career Tips",
          imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
          isPublished: true
        },
        {
          title: "The Future of Work: Industry Trends Shaping 2024",
          slug: "future-of-work-industry-trends-2024",
          excerpt: "Explore the key workplace trends and industry shifts that will define career opportunities and professional growth in 2024.",
          content: "The workplace continues to evolve rapidly, driven by technological advancement, changing employee expectations, and global economic shifts. Understanding these trends is crucial for career planning and professional development.\n\nArtificial Intelligence Integration\nAI is no longer a futuristic concept but a present reality. Organizations are integrating AI tools to automate routine tasks, enhance decision-making, and improve customer experiences. Professionals who can work alongside AI and leverage its capabilities will be most valuable.\n\nHybrid Work Models\nThe traditional 9-to-5 office model is giving way to flexible, hybrid arrangements. Companies are adopting policies that balance remote work benefits with in-person collaboration needs.\n\nSkills-Based Hiring\nEmployers are increasingly prioritizing skills and competencies over formal degrees. This shift creates opportunities for non-traditional candidates and emphasizes continuous learning.\n\nSustainability Focus\nEnvironmental consciousness is driving business decisions. Green jobs and sustainability-focused roles are growing rapidly across industries.\n\nMental Health Priority\nEmployee wellbeing has become a business priority. Companies are investing in mental health support, flexible schedules, and wellness programs.",
          category: "Industry Trends",
          imageUrl: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
          isPublished: true
        }
      ];

      // Insert sample data
      for (const job of sampleJobs) {
        await storage.createJobPost(job);
      }

      for (const article of sampleArticles) {
        await storage.createCareerArticle(article);
      }

      res.json({ message: "Sample data seeded successfully" });
    } catch (error) {
      console.error("Error seeding data:", error);
      res.status(500).json({ message: "Failed to seed sample data" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static('uploads'));

  const httpServer = createServer(app);
  return httpServer;
}
