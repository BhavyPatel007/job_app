import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const jobPosts = pgTable("job_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location").notNull(),
  type: text("type").notNull(), // Full-time, Part-time, Contract, etc.
  salary: text("salary"),
  description: text("description").notNull(),
  requirements: text("requirements").notNull(),
  skills: text("skills").array().notNull().default([]),
  excerpt: text("excerpt").notNull(),
  companyLogo: text("company_logo"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const careerArticles = pgTable("career_articles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(), // Career Tips, Industry Trends, Skills, etc.
  imageUrl: text("image_url"),
  isPublished: boolean("is_published").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const applications = pgTable("applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").default(""),
  experience: text("experience").default(""),
  position: text("position").default(""),
  coverLetter: text("cover_letter"),
  resumeUrl: text("resume_url"),
  certificatesUrls: text("certificates_urls").array().default([]),
  termsAccepted: boolean("terms_accepted").notNull().default(false),
  marketingConsent: boolean("marketing_consent").notNull().default(false),
  jobPostId: varchar("job_post_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const jobPostsRelations = relations(jobPosts, ({ many }) => ({
  applications: many(applications),
}));

export const applicationsRelations = relations(applications, ({ one }) => ({
  jobPost: one(jobPosts, {
    fields: [applications.jobPostId],
    references: [jobPosts.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertJobPostSchema = createInsertSchema(jobPosts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCareerArticleSchema = createInsertSchema(careerArticles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertJobPost = z.infer<typeof insertJobPostSchema>;
export type JobPost = typeof jobPosts.$inferSelect;

export type InsertCareerArticle = z.infer<typeof insertCareerArticleSchema>;
export type CareerArticle = typeof careerArticles.$inferSelect;

export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applications.$inferSelect;
