import { Link } from "wouter";
import { Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

export default function Footer() {
  const jobSeekerLinks = [
    "Browse Jobs",
    "Career Advice", 
    "Resume Builder",
    "Salary Guide",
    "Job Alerts"
  ];

  const employerLinks = [
    "Post a Job",
    "Browse Resumes",
    "Pricing",
    "Employer Tools",
    "Support"
  ];

  const socialLinks = [
    { icon: Facebook, href: "#", name: "Facebook" },
    { icon: Twitter, href: "#", name: "Twitter" },
    { icon: Linkedin, href: "#", name: "LinkedIn" },
    { icon: Instagram, href: "#", name: "Instagram" },
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-bold mb-4">CareerHub</h3>
            <p className="text-gray-300 mb-4 max-w-md">
              Connecting talented professionals with amazing opportunities. Find your next career move with our comprehensive job platform.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a 
                  key={social.name}
                  href={social.href} 
                  className="text-gray-400 hover:text-white transition-colors"
                  data-testid={`link-social-${index}`}
                  aria-label={social.name}
                >
                  <social.icon className="h-6 w-6" />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">For Job Seekers</h4>
            <ul className="space-y-2 text-gray-300">
              {jobSeekerLinks.map((link, index) => (
                <li key={link}>
                  <Link 
                    href="/" 
                    className="hover:text-white transition-colors"
                    data-testid={`link-job-seeker-${index}`}
                  >
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">For Employers</h4>
            <ul className="space-y-2 text-gray-300">
              {employerLinks.map((link, index) => (
                <li key={link}>
                  <Link 
                    href="/" 
                    className="hover:text-white transition-colors"
                    data-testid={`link-employer-${index}`}
                  >
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>
            &copy; 2024 CareerHub. All rights reserved. | 
            <Link href="/" className="hover:text-white ml-1" data-testid="link-privacy">
              Privacy Policy
            </Link> | 
            <Link href="/" className="hover:text-white ml-1" data-testid="link-terms">
              Terms of Service
            </Link>
          </p>
        </div>
      </div>
    </footer>
  );
}
