import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigation = [
    { name: "Jobs", href: "/" },
    { name: "Career Advice", href: "/" },
    { name: "Companies", href: "/" },
    { name: "Resources", href: "/" },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/" data-testid="link-logo">
                <h1 className="text-2xl font-bold text-primary cursor-pointer">CareerHub</h1>
              </Link>
            </div>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-4">
                {navigation.map((item, index) => (
                  <Link 
                    key={item.name}
                    href={item.href}
                    className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors"
                    data-testid={`link-nav-${index}`}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="ml-4 flex items-center md:ml-6">
              <Button 
                variant="outline" 
                className="mr-3"
                data-testid="button-sign-in"
              >
                Sign In
              </Button>
              <Button data-testid="button-post-job">
                Post a Job
              </Button>
            </div>
          </div>
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <div className="flex flex-col space-y-2">
              {navigation.map((item, index) => (
                <Link 
                  key={item.name}
                  href={item.href}
                  className="text-gray-900 hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors"
                  data-testid={`link-mobile-nav-${index}`}
                >
                  {item.name}
                </Link>
              ))}
              <div className="px-3 py-2 space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full"
                  data-testid="button-mobile-sign-in"
                >
                  Sign In
                </Button>
                <Button 
                  className="w-full"
                  data-testid="button-mobile-post-job"
                >
                  Post a Job
                </Button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
