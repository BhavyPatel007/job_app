import { Link } from "wouter";
import { type CareerArticle } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface ArticleCardProps {
  article: CareerArticle;
}

export default function ArticleCard({ article }: ArticleCardProps) {
  const getBadgeVariant = (category: string) => {
    switch (category.toLowerCase()) {
      case 'career tips':
        return 'default';
      case 'industry trends':
        return 'secondary';
      case 'skills':
        return 'outline';
      default:
        return 'default';
    }
  };

  const timeAgo = (date: string | Date) => {
    const now = new Date();
    const articleDate = typeof date === 'string' ? new Date(date) : date;
    const diffInDays = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) return 'Today';
    if (diffInDays === 1) return '1 day ago';
    if (diffInDays < 7) return `${diffInDays} days ago`;
    if (diffInDays < 14) return '1 week ago';
    if (diffInDays < 30) return `${Math.floor(diffInDays / 7)} weeks ago`;
    return articleDate.toLocaleDateString();
  };

  return (
    <article className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden" data-testid={`card-article-${article.id}`}>
      {article.imageUrl ? (
        <img 
          src={article.imageUrl} 
          alt={article.title}
          className="w-full h-48 object-cover"
          data-testid={`img-article-${article.id}`}
        />
      ) : (
        <div className="w-full h-48 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
          <div className="text-4xl text-gray-400">📝</div>
        </div>
      )}
      
      <div className="p-6">
        <div className="flex items-center mb-3">
          <Badge variant={getBadgeVariant(article.category)} data-testid={`badge-article-category-${article.id}`}>
            {article.category}
          </Badge>
          <span className="text-muted text-sm ml-auto" data-testid={`text-article-date-${article.id}`}>
            {timeAgo(article.createdAt)}
          </span>
        </div>

        <h3 className="text-xl font-bold text-gray-900 mb-3" data-testid={`text-article-title-${article.id}`}>
          {article.title}
        </h3>

        <p className="text-muted mb-4" data-testid={`text-article-excerpt-${article.id}`}>
          {article.excerpt}
        </p>

        <Link href={`/articles/${article.slug}`}>
          <Button 
            variant="ghost" 
            className="text-primary hover:text-blue-700 p-0 h-auto font-medium"
            data-testid={`button-read-article-${article.id}`}
          >
            Read More <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </Link>
      </div>
    </article>
  );
}
