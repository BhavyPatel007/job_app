import { Link } from "wouter";
import { type JobPost } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, ArrowRight } from "lucide-react";

interface JobCardProps {
  job: JobPost;
}

export default function JobCard({ job }: JobCardProps) {
  const getBadgeVariant = (type: string) => {
    switch (type.toLowerCase()) {
      case 'full-time':
        return 'secondary';
      case 'contract':
        return 'outline';
      case 'part-time':
        return 'secondary';
      default:
        return 'secondary';
    }
  };

  return (
    <article className="bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-shadow p-6" data-testid={`card-job-${job.id}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center">
          <div className="w-12 h-12 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center text-white font-bold mr-4">
            {job.company.charAt(0)}
          </div>
          <div>
            <h3 className="font-semibold text-gray-900" data-testid={`text-job-company-${job.id}`}>
              {job.company}
            </h3>
            <div className="flex items-center text-sm text-muted">
              <MapPin className="h-3 w-3 mr-1" />
              <span data-testid={`text-job-location-${job.id}`}>{job.location}</span>
            </div>
          </div>
        </div>
        <Badge variant={getBadgeVariant(job.type)} data-testid={`badge-job-type-${job.id}`}>
          {job.type}
        </Badge>
      </div>

      <h4 className="text-xl font-bold text-gray-900 mb-3" data-testid={`text-job-title-${job.id}`}>
        {job.title}
      </h4>

      <p className="text-muted mb-4 line-clamp-3" data-testid={`text-job-excerpt-${job.id}`}>
        {job.excerpt}
      </p>

      <div className="flex flex-wrap gap-2 mb-4">
        {job.skills.slice(0, 3).map((skill, index) => (
          <Badge 
            key={index} 
            variant="outline" 
            className="text-xs"
            data-testid={`badge-job-skill-${job.id}-${index}`}
          >
            {skill}
          </Badge>
        ))}
        {job.skills.length > 3 && (
          <Badge variant="outline" className="text-xs" data-testid={`badge-job-skills-more-${job.id}`}>
            +{job.skills.length - 3} more
          </Badge>
        )}
      </div>

      <div className="flex items-center justify-between">
        {job.salary && (
          <span className="font-semibold text-primary" data-testid={`text-job-salary-${job.id}`}>
            {job.salary}
          </span>
        )}
        <Link href={`/jobs/${job.id}`}>
          <Button 
            variant="ghost" 
            className="text-primary hover:text-blue-700 p-0 h-auto font-medium"
            data-testid={`button-view-job-${job.id}`}
          >
            View Details <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </Link>
      </div>
    </article>
  );
}
