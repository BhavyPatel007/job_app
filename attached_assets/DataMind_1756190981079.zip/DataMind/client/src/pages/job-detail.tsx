import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { type JobPost } from "@shared/schema";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import ApplicationForm from "@/components/application-form";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Building, Clock, DollarSign } from "lucide-react";

export default function JobDetail() {
  const { id } = useParams();
  
  const { data: job, isLoading, error } = useQuery<JobPost>({
    queryKey: ["/api/jobs", id],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <Skeleton className="h-8 w-3/4 mb-4" />
          <Skeleton className="h-6 w-1/2 mb-8" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Skeleton className="h-64 w-full" />
            </div>
            <div>
              <Skeleton className="h-48 w-full" />
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Job Not Found</h1>
            <p className="text-muted">The job posting you're looking for doesn't exist or has been removed.</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-8">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xl mr-4">
                    {job.company.charAt(0)}
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="text-job-title">{job.title}</h1>
                    <div className="flex items-center gap-4 text-muted">
                      <div className="flex items-center">
                        <Building className="h-4 w-4 mr-1" />
                        <span data-testid="text-job-company">{job.company}</span>
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span data-testid="text-job-location">{job.location}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <Badge variant="secondary" data-testid="badge-job-type">{job.type}</Badge>
              </div>

              <div className="flex items-center gap-4 mb-8">
                {job.salary && (
                  <div className="flex items-center text-primary font-semibold">
                    <DollarSign className="h-4 w-4 mr-1" />
                    <span data-testid="text-job-salary">{job.salary}</span>
                  </div>
                )}
                <div className="flex items-center text-muted">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>Posted {new Date(job.createdAt).toLocaleDateString()}</span>
                </div>
              </div>

              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Job Description</h2>
                <div className="prose prose-gray max-w-none" data-testid="text-job-description">
                  {job.description.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4">{paragraph}</p>
                  ))}
                </div>
              </div>

              <div className="mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Requirements</h2>
                <div className="prose prose-gray max-w-none" data-testid="text-job-requirements">
                  {job.requirements.split('\n').map((requirement, index) => (
                    <p key={index} className="mb-2">• {requirement}</p>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold text-gray-900 mb-4">Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {job.skills.map((skill, index) => (
                    <Badge key={index} variant="outline" data-testid={`badge-skill-${index}`}>
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div>
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Apply for this position</h3>
                <p className="text-muted mb-4">
                  Use our quick application form below to apply for this position. Your information will be sent directly to the hiring team.
                </p>
                <a 
                  href="#application-form" 
                  className="inline-block bg-primary hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors w-full text-center"
                  data-testid="button-apply-now"
                >
                  Apply Now
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <ApplicationForm jobId={job.id} />
      <Footer />
    </div>
  );
}
