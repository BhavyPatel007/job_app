import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { type CareerArticle } from "@shared/schema";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "lucide-react";

export default function ArticleDetail() {
  const { slug } = useParams();
  
  const { data: article, isLoading, error } = useQuery<CareerArticle>({
    queryKey: ["/api/articles", slug],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <Skeleton className="h-8 w-3/4 mb-4" />
          <Skeleton className="h-6 w-1/2 mb-8" />
          <Skeleton className="h-64 w-full mb-8" />
          <Skeleton className="h-96 w-full" />
        </div>
        <Footer />
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Article Not Found</h1>
            <p className="text-muted">The article you're looking for doesn't exist or has been removed.</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <article className="bg-white rounded-xl shadow-sm overflow-hidden">
          {article.imageUrl && (
            <img 
              src={article.imageUrl} 
              alt={article.title}
              className="w-full h-64 object-cover"
              data-testid="img-article-hero"
            />
          )}
          
          <div className="p-8">
            <div className="flex items-center gap-4 mb-6">
              <Badge variant="secondary" data-testid="badge-article-category">
                {article.category}
              </Badge>
              <div className="flex items-center text-muted text-sm">
                <Calendar className="h-4 w-4 mr-1" />
                <span data-testid="text-article-date">
                  {new Date(article.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>

            <h1 className="text-4xl font-bold text-gray-900 mb-6" data-testid="text-article-title">
              {article.title}
            </h1>

            <p className="text-xl text-muted mb-8" data-testid="text-article-excerpt">
              {article.excerpt}
            </p>

            <div className="prose prose-gray prose-lg max-w-none" data-testid="text-article-content">
              {article.content.split('\n\n').map((paragraph, index) => (
                <p key={index} className="mb-6">{paragraph}</p>
              ))}
            </div>
          </div>
        </article>
      </div>

      <Footer />
    </div>
  );
}
