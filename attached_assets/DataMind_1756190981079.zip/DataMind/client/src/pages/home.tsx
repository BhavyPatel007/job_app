import { useQuery } from "@tanstack/react-query";
import { type JobPost, type CareerArticle } from "@shared/schema";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import JobCard from "@/components/job-card";
import ArticleCard from "@/components/article-card";
import ApplicationForm from "@/components/application-form";
import { Skeleton } from "@/components/ui/skeleton";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Home() {
  const { data: jobs, isLoading: jobsLoading } = useQuery<JobPost[]>({
    queryKey: ["/api/jobs"],
  });

  const { data: articles, isLoading: articlesLoading } = useQuery<CareerArticle[]>({
    queryKey: ["/api/articles"],
  });

  const featuredJobs = jobs?.slice(0, 3) || [];
  const featuredArticles = articles?.slice(0, 3) || [];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Find Your Dream Job
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto">
              Discover thousands of job opportunities and get expert career advice to accelerate your professional journey.
            </p>
            <div className="max-w-2xl mx-auto">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative">
                  <Input 
                    type="text" 
                    placeholder="Search jobs, companies, or keywords..." 
                    className="w-full px-6 py-4 text-gray-900 placeholder-gray-500"
                    data-testid="input-search-jobs"
                  />
                  <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-muted h-5 w-5" />
                </div>
                <Button 
                  className="bg-secondary hover:bg-green-600 text-white px-8 py-4 font-semibold"
                  data-testid="button-search-jobs"
                >
                  Search Jobs
                </Button>
              </div>
            </div>
            <div className="mt-8 flex flex-wrap justify-center gap-4 text-sm">
              <span className="bg-blue-600 bg-opacity-50 px-3 py-1 rounded-full">Remote</span>
              <span className="bg-blue-600 bg-opacity-50 px-3 py-1 rounded-full">Full-time</span>
              <span className="bg-blue-600 bg-opacity-50 px-3 py-1 rounded-full">Tech</span>
              <span className="bg-blue-600 bg-opacity-50 px-3 py-1 rounded-full">Marketing</span>
              <span className="bg-blue-600 bg-opacity-50 px-3 py-1 rounded-full">Design</span>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Jobs Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Featured Job Opportunities</h2>
            <p className="text-xl text-muted max-w-2xl mx-auto">Explore hand-picked job opportunities from top companies across various industries.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {jobsLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="bg-white border border-gray-200 rounded-xl shadow-sm p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center">
                      <Skeleton className="w-12 h-12 rounded-lg mr-4" />
                      <div>
                        <Skeleton className="h-4 w-24 mb-2" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                    </div>
                    <Skeleton className="h-6 w-16 rounded-full" />
                  </div>
                  <Skeleton className="h-6 w-full mb-3" />
                  <Skeleton className="h-16 w-full mb-4" />
                  <div className="flex gap-2 mb-4">
                    <Skeleton className="h-6 w-16 rounded" />
                    <Skeleton className="h-6 w-20 rounded" />
                    <Skeleton className="h-6 w-14 rounded" />
                  </div>
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-5 w-24" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                </div>
              ))
            ) : (
              featuredJobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))
            )}
          </div>

          <div className="text-center mt-12">
            <Button className="bg-primary hover:bg-blue-700 text-white px-8 py-3 font-semibold" data-testid="button-view-all-jobs">
              View All Jobs
            </Button>
          </div>
        </div>
      </section>

      {/* Career Advice Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Career Advice & Insights</h2>
            <p className="text-xl text-muted max-w-2xl mx-auto">Stay ahead with expert tips, industry trends, and career guidance from industry professionals.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {articlesLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm overflow-hidden">
                  <Skeleton className="w-full h-48" />
                  <div className="p-6">
                    <div className="flex items-center mb-3">
                      <Skeleton className="h-6 w-20 rounded-full mr-auto" />
                      <Skeleton className="h-4 w-16" />
                    </div>
                    <Skeleton className="h-6 w-full mb-3" />
                    <Skeleton className="h-12 w-full mb-4" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                </div>
              ))
            ) : (
              featuredArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))
            )}
          </div>
        </div>
      </section>

      {/* Application Form Section */}
      <ApplicationForm />

      {/* Stats Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl md:text-5xl font-bold mb-2" data-testid="text-stat-jobs">15,000+</div>
              <div className="text-blue-200">Active Jobs</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold mb-2" data-testid="text-stat-companies">2,500+</div>
              <div className="text-blue-200">Companies</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold mb-2" data-testid="text-stat-candidates">50,000+</div>
              <div className="text-blue-200">Job Seekers</div>
            </div>
            <div>
              <div className="text-4xl md:text-5xl font-bold mb-2" data-testid="text-stat-placements">8,000+</div>
              <div className="text-blue-200">Successful Hires</div>
            </div>
          </div>
        </div>
      </section>

      <Footer />

      {/* AdSense Placeholder */}
      <div className="fixed bottom-4 right-4 bg-gray-800 text-white p-4 rounded-lg shadow-lg max-w-xs" data-testid="ad-space">
        <div className="text-xs text-gray-400 mb-1">Advertisement</div>
        <div className="bg-gray-700 p-4 rounded text-center">
          <div className="text-sm">AdSense Space</div>
          <div className="text-xs text-gray-400 mt-1">300x250</div>
        </div>
      </div>
    </div>
  );
}
