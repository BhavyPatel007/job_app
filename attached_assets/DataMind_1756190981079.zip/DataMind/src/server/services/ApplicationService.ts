import { db } from "../config/database";
import { applications, jobPosts } from "../../shared/schema";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { ApplicationModel, type Application, type InsertApplication } from "../models/Application";

export class ApplicationService {
  static async findAll(filters?: {
    jobPostId?: string;
    email?: string;
    dateFrom?: Date;
    dateTo?: Date;
    page?: number;
    limit?: number;
  }): Promise<{ data: Application[], total: number, page: number, totalPages: number }> {
    const { jobPostId, email, dateFrom, dateTo, page = 1, limit = 20 } = filters || {};
    const offset = (page - 1) * limit;

    let whereClause = undefined;

    if (jobPostId) {
      whereClause = and(whereClause, eq(applications.jobPostId, jobPostId));
    }

    if (email) {
      whereClause = and(whereClause, eq(applications.email, email));
    }

    if (dateFrom) {
      whereClause = and(whereClause, gte(applications.createdAt, dateFrom));
    }

    if (dateTo) {
      whereClause = and(whereClause, lte(applications.createdAt, dateTo));
    }

    const [data, totalResult] = await Promise.all([
      db.select({
        application: applications,
        jobTitle: jobPosts.title,
        company: jobPosts.company
      })
        .from(applications)
        .leftJoin(jobPosts, eq(applications.jobPostId, jobPosts.id))
        .where(whereClause)
        .orderBy(desc(applications.createdAt))
        .limit(limit)
        .offset(offset),
      db.select({ count: applications.id })
        .from(applications)
        .where(whereClause)
    ]);

    const total = totalResult.length;
    const totalPages = Math.ceil(total / limit);

    return { 
      data: data.map(row => ({ 
        ...row.application, 
        jobTitle: row.jobTitle, 
        company: row.company 
      })) as any[], 
      total, 
      page, 
      totalPages 
    };
  }

  static async findById(id: string): Promise<Application | null> {
    const [application] = await db
      .select({
        application: applications,
        jobTitle: jobPosts.title,
        company: jobPosts.company
      })
      .from(applications)
      .leftJoin(jobPosts, eq(applications.jobPostId, jobPosts.id))
      .where(eq(applications.id, id));
    
    if (!application) return null;

    return {
      ...application.application,
      jobTitle: application.jobTitle,
      company: application.company
    } as any;
  }

  static async create(data: InsertApplication): Promise<Application> {
    const validatedData = ApplicationModel.validateInsert(data);
    
    const [application] = await db
      .insert(applications)
      .values(validatedData)
      .returning();
    
    return application;
  }

  static async update(id: string, data: Partial<InsertApplication>): Promise<Application | null> {
    const validatedData = ApplicationModel.validateUpdate(data);
    
    const [application] = await db
      .update(applications)
      .set(validatedData)
      .where(eq(applications.id, id))
      .returning();
    
    return application || null;
  }

  static async delete(id: string): Promise<boolean> {
    const result = await db
      .delete(applications)
      .where(eq(applications.id, id));
    
    return result.rowCount > 0;
  }

  static async getByJobPost(jobPostId: string, limit: number = 50): Promise<Application[]> {
    return await db
      .select()
      .from(applications)
      .where(eq(applications.jobPostId, jobPostId))
      .orderBy(desc(applications.createdAt))
      .limit(limit);
  }

  static async getRecentApplications(limit: number = 10): Promise<Application[]> {
    return await db
      .select({
        application: applications,
        jobTitle: jobPosts.title,
        company: jobPosts.company
      })
      .from(applications)
      .leftJoin(jobPosts, eq(applications.jobPostId, jobPosts.id))
      .orderBy(desc(applications.createdAt))
      .limit(limit)
      .then(rows => rows.map(row => ({
        ...row.application,
        jobTitle: row.jobTitle,
        company: row.company
      })) as any[]);
  }
}