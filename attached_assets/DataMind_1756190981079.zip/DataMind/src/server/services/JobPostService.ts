import { db } from "../config/database";
import { jobPosts, applications } from "../../shared/schema";
import { eq, desc, like, and, or, inArray } from "drizzle-orm";
import { JobPostModel, type JobPost, type InsertJobPost } from "../models/JobPost";

export class JobPostService {
  static async findAll(filters?: {
    query?: string;
    location?: string;
    type?: string;
    skills?: string[];
    page?: number;
    limit?: number;
  }): Promise<{ data: JobPost[], total: number, page: number, totalPages: number }> {
    const { query, location, type, skills, page = 1, limit = 10 } = filters || {};
    const offset = (page - 1) * limit;

    let whereClause = eq(jobPosts.isActive, true);

    if (query) {
      whereClause = and(
        whereClause,
        or(
          like(jobPosts.title, `%${query}%`),
          like(jobPosts.company, `%${query}%`),
          like(jobPosts.description, `%${query}%`)
        )
      );
    }

    if (location) {
      whereClause = and(whereClause, like(jobPosts.location, `%${location}%`));
    }

    if (type) {
      whereClause = and(whereClause, eq(jobPosts.type, type));
    }

    if (skills && skills.length > 0) {
      // PostgreSQL array overlap operation
      const skillsArray = skills;
      whereClause = and(whereClause, inArray(jobPosts.skills, skillsArray));
    }

    const [data, totalResult] = await Promise.all([
      db.select()
        .from(jobPosts)
        .where(whereClause)
        .orderBy(desc(jobPosts.createdAt))
        .limit(limit)
        .offset(offset),
      db.select({ count: jobPosts.id })
        .from(jobPosts)
        .where(whereClause)
    ]);

    const total = totalResult.length;
    const totalPages = Math.ceil(total / limit);

    return { data, total, page, totalPages };
  }

  static async findById(id: string): Promise<JobPost | null> {
    const [job] = await db
      .select()
      .from(jobPosts)
      .where(eq(jobPosts.id, id));
    
    return job || null;
  }

  static async create(data: InsertJobPost): Promise<JobPost> {
    const validatedData = JobPostModel.validateInsert(data);
    
    const [job] = await db
      .insert(jobPosts)
      .values(validatedData)
      .returning();
    
    return job;
  }

  static async update(id: string, data: Partial<InsertJobPost>): Promise<JobPost | null> {
    const validatedData = JobPostModel.validateUpdate(data);
    
    const [job] = await db
      .update(jobPosts)
      .set({ ...validatedData, updatedAt: new Date() })
      .where(eq(jobPosts.id, id))
      .returning();
    
    return job || null;
  }

  static async delete(id: string): Promise<boolean> {
    const result = await db
      .update(jobPosts)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(jobPosts.id, id));
    
    return result.rowCount > 0;
  }

  static async getApplicationsCount(id: string): Promise<number> {
    const result = await db
      .select({ count: applications.id })
      .from(applications)
      .where(eq(applications.jobPostId, id));
    
    return result.length;
  }

  static async getFeatured(limit: number = 6): Promise<JobPost[]> {
    return await db
      .select()
      .from(jobPosts)
      .where(eq(jobPosts.isActive, true))
      .orderBy(desc(jobPosts.createdAt))
      .limit(limit);
  }
}