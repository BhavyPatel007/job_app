import { db } from "../config/database";
import { careerArticles } from "../../shared/schema";
import { eq, desc, like, and, or } from "drizzle-orm";
import { CareerArticleModel, type CareerArticle, type InsertCareerArticle } from "../models/CareerArticle";

export class CareerArticleService {
  static async findAll(filters?: {
    query?: string;
    category?: string;
    published?: boolean;
    page?: number;
    limit?: number;
  }): Promise<{ data: CareerArticle[], total: number, page: number, totalPages: number }> {
    const { query, category, published = true, page = 1, limit = 10 } = filters || {};
    const offset = (page - 1) * limit;

    let whereClause = eq(careerArticles.isPublished, published);

    if (query) {
      whereClause = and(
        whereClause,
        or(
          like(careerArticles.title, `%${query}%`),
          like(careerArticles.excerpt, `%${query}%`),
          like(careerArticles.content, `%${query}%`)
        )
      );
    }

    if (category) {
      whereClause = and(whereClause, eq(careerArticles.category, category));
    }

    const [data, totalResult] = await Promise.all([
      db.select()
        .from(careerArticles)
        .where(whereClause)
        .orderBy(desc(careerArticles.createdAt))
        .limit(limit)
        .offset(offset),
      db.select({ count: careerArticles.id })
        .from(careerArticles)
        .where(whereClause)
    ]);

    const total = totalResult.length;
    const totalPages = Math.ceil(total / limit);

    return { data, total, page, totalPages };
  }

  static async findById(id: string): Promise<CareerArticle | null> {
    const [article] = await db
      .select()
      .from(careerArticles)
      .where(eq(careerArticles.id, id));
    
    return article || null;
  }

  static async findBySlug(slug: string): Promise<CareerArticle | null> {
    const [article] = await db
      .select()
      .from(careerArticles)
      .where(eq(careerArticles.slug, slug));
    
    return article || null;
  }

  static async create(data: InsertCareerArticle): Promise<CareerArticle> {
    const validatedData = CareerArticleModel.validateInsert(data);
    
    // Generate slug if not provided
    if (!validatedData.slug) {
      validatedData.slug = CareerArticleModel.generateSlug(validatedData.title);
    }
    
    const [article] = await db
      .insert(careerArticles)
      .values(validatedData)
      .returning();
    
    return article;
  }

  static async update(id: string, data: Partial<InsertCareerArticle>): Promise<CareerArticle | null> {
    const validatedData = CareerArticleModel.validateUpdate(data);
    
    // Regenerate slug if title is updated
    if (validatedData.title && !validatedData.slug) {
      validatedData.slug = CareerArticleModel.generateSlug(validatedData.title);
    }
    
    const [article] = await db
      .update(careerArticles)
      .set({ ...validatedData, updatedAt: new Date() })
      .where(eq(careerArticles.id, id))
      .returning();
    
    return article || null;
  }

  static async delete(id: string): Promise<boolean> {
    const result = await db
      .update(careerArticles)
      .set({ isPublished: false, updatedAt: new Date() })
      .where(eq(careerArticles.id, id));
    
    return result.rowCount > 0;
  }

  static async getFeatured(limit: number = 6): Promise<CareerArticle[]> {
    return await db
      .select()
      .from(careerArticles)
      .where(eq(careerArticles.isPublished, true))
      .orderBy(desc(careerArticles.createdAt))
      .limit(limit);
  }

  static async getCategories(): Promise<string[]> {
    const result = await db
      .selectDistinct({ category: careerArticles.category })
      .from(careerArticles)
      .where(eq(careerArticles.isPublished, true));
    
    return result.map(r => r.category);
  }
}