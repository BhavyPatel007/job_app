import { z } from "zod";
import { applications, insertApplicationSchema, type InsertApplication, type Application } from "../../shared/schema";

export class ApplicationModel {
  static validateInsert(data: unknown): InsertApplication {
    return insertApplicationSchema.parse(data);
  }

  static validateUpdate(data: unknown): Partial<InsertApplication> {
    return insertApplicationSchema.partial().parse(data);
  }

  static validateSearch(data: unknown) {
    const searchSchema = z.object({
      jobPostId: z.string().optional(),
      email: z.string().email().optional(),
      status: z.enum(['pending', 'reviewing', 'accepted', 'rejected']).optional(),
      dateFrom: z.date().optional(),
      dateTo: z.date().optional(),
      page: z.number().min(1).default(1),
      limit: z.number().min(1).max(100).default(20)
    });
    return searchSchema.parse(data);
  }

  static sanitizeForAdmin(application: Application) {
    // Remove sensitive data when returning to admin
    const { id, fullName, email, position, experience, jobPostId, createdAt } = application;
    return { id, fullName, email, position, experience, jobPostId, createdAt };
  }
}

export { type Application, type InsertApplication };