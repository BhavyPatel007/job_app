import { z } from "zod";
import { users, insertUserSchema, type InsertUser, type User } from "../../shared/schema";

export class UserModel {
  static validateInsert(data: unknown): InsertUser {
    return insertUserSchema.parse(data);
  }

  static validatePartialUpdate(data: unknown): Partial<InsertUser> {
    return insertUserSchema.partial().parse(data);
  }
}

export { type User, type InsertUser };