import { z } from "zod";
import { careerArticles, insertCareerArticleSchema, type InsertCareerArticle, type CareerArticle } from "../../shared/schema";

export class CareerArticleModel {
  static validateInsert(data: unknown): InsertCareerArticle {
    return insertCareerArticleSchema.parse(data);
  }

  static validateUpdate(data: unknown): Partial<InsertCareerArticle> {
    return insertCareerArticleSchema.partial().parse(data);
  }

  static validateSearch(data: unknown) {
    const searchSchema = z.object({
      query: z.string().optional(),
      category: z.string().optional(),
      published: z.boolean().optional().default(true),
      page: z.number().min(1).default(1),
      limit: z.number().min(1).max(50).default(10)
    });
    return searchSchema.parse(data);
  }

  static generateSlug(title: string): string {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }
}

export { type CareerArticle, type InsertCareerArticle };