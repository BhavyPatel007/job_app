import { z } from "zod";
import { jobPosts, insertJobPostSchema, type InsertJobPost, type JobPost } from "../../shared/schema";

export class JobPostModel {
  static validateInsert(data: unknown): InsertJobPost {
    return insertJobPostSchema.parse(data);
  }

  static validateUpdate(data: unknown): Partial<InsertJobPost> {
    return insertJobPostSchema.partial().parse(data);
  }

  static validateSearch(data: unknown) {
    const searchSchema = z.object({
      query: z.string().optional(),
      location: z.string().optional(),
      type: z.string().optional(),
      skills: z.array(z.string()).optional(),
      salaryMin: z.number().optional(),
      salaryMax: z.number().optional(),
      page: z.number().min(1).default(1),
      limit: z.number().min(1).max(100).default(10)
    });
    return searchSchema.parse(data);
  }
}

export { type JobPost, type InsertJobPost };