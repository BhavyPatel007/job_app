import { Request, Response } from "express";
import { CareerArticleService } from "../services/CareerArticleService";
import { CareerArticleModel } from "../models/CareerArticle";
import { z } from "zod";

export class CareerArticleController {
  static async getAll(req: Request, res: Response) {
    try {
      const query = req.query;
      
      const filters = {
        query: query.q as string,
        category: query.category as string,
        published: query.published !== 'false',
        page: query.page ? parseInt(query.page as string) : 1,
        limit: query.limit ? parseInt(query.limit as string) : 10
      };

      const result = await CareerArticleService.findAll(filters);
      
      res.json({
        success: true,
        data: result.data,
        pagination: {
          page: result.page,
          limit: filters.limit,
          total: result.total,
          totalPages: result.totalPages
        }
      });
    } catch (error) {
      console.error("Error fetching career articles:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch career articles",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async getById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const article = await CareerArticleService.findById(id);
      
      if (!article) {
        return res.status(404).json({
          success: false,
          message: "Article not found"
        });
      }

      res.json({
        success: true,
        data: article
      });
    } catch (error) {
      console.error("Error fetching article:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch article",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async getBySlug(req: Request, res: Response) {
    try {
      const { slug } = req.params;
      const article = await CareerArticleService.findBySlug(slug);
      
      if (!article) {
        return res.status(404).json({
          success: false,
          message: "Article not found"
        });
      }

      res.json({
        success: true,
        data: article
      });
    } catch (error) {
      console.error("Error fetching article by slug:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch article",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async create(req: Request, res: Response) {
    try {
      const articleData = CareerArticleModel.validateInsert(req.body);
      const article = await CareerArticleService.create(articleData);
      
      res.status(201).json({
        success: true,
        data: article,
        message: "Article created successfully"
      });
    } catch (error) {
      console.error("Error creating article:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid article data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "Failed to create article",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async update(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const updateData = CareerArticleModel.validateUpdate(req.body);
      
      const article = await CareerArticleService.update(id, updateData);
      
      if (!article) {
        return res.status(404).json({
          success: false,
          message: "Article not found"
        });
      }

      res.json({
        success: true,
        data: article,
        message: "Article updated successfully"
      });
    } catch (error) {
      console.error("Error updating article:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid update data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "Failed to update article",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async delete(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const success = await CareerArticleService.delete(id);
      
      if (!success) {
        return res.status(404).json({
          success: false,
          message: "Article not found"
        });
      }

      res.json({
        success: true,
        message: "Article deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting article:", error);
      res.status(500).json({
        success: false,
        message: "Failed to delete article",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async getFeatured(req: Request, res: Response) {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 6;
      const articles = await CareerArticleService.getFeatured(limit);
      
      res.json({
        success: true,
        data: articles
      });
    } catch (error) {
      console.error("Error fetching featured articles:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch featured articles",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async getCategories(req: Request, res: Response) {
    try {
      const categories = await CareerArticleService.getCategories();
      
      res.json({
        success: true,
        data: categories
      });
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch categories",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }
}