import { Request, Response } from "express";
import { ApplicationService } from "../services/ApplicationService";
import { ApplicationModel } from "../models/Application";
import { z } from "zod";

export class ApplicationController {
  static async getAll(req: Request, res: Response) {
    try {
      const query = req.query;
      
      const filters = {
        jobPostId: query.jobPostId as string,
        email: query.email as string,
        dateFrom: query.dateFrom ? new Date(query.dateFrom as string) : undefined,
        dateTo: query.dateTo ? new Date(query.dateTo as string) : undefined,
        page: query.page ? parseInt(query.page as string) : 1,
        limit: query.limit ? parseInt(query.limit as string) : 20
      };

      const result = await ApplicationService.findAll(filters);
      
      res.json({
        success: true,
        data: result.data,
        pagination: {
          page: result.page,
          limit: filters.limit,
          total: result.total,
          totalPages: result.totalPages
        }
      });
    } catch (error) {
      console.error("Error fetching applications:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch applications",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async getById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const application = await ApplicationService.findById(id);
      
      if (!application) {
        return res.status(404).json({
          success: false,
          message: "Application not found"
        });
      }

      res.json({
        success: true,
        data: application
      });
    } catch (error) {
      console.error("Error fetching application:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch application",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async create(req: Request, res: Response) {
    try {
      // Handle multipart form data
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      const applicationData = {
        ...req.body,
        termsAccepted: req.body.termsAccepted === 'true',
        marketingConsent: req.body.marketingConsent === 'true',
        resumeUrl: files?.resume?.[0]?.filename || null,
        certificatesUrls: files?.certificates?.map(file => file.filename) || [],
      };

      const validatedData = ApplicationModel.validateInsert(applicationData);
      const application = await ApplicationService.create(validatedData);
      
      res.status(201).json({
        success: true,
        data: {
          id: application.id,
          message: "Application submitted successfully"
        },
        message: "Application submitted successfully"
      });
    } catch (error) {
      console.error("Error creating application:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid application data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "Failed to submit application",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async update(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const updateData = ApplicationModel.validateUpdate(req.body);
      
      const application = await ApplicationService.update(id, updateData);
      
      if (!application) {
        return res.status(404).json({
          success: false,
          message: "Application not found"
        });
      }

      res.json({
        success: true,
        data: application,
        message: "Application updated successfully"
      });
    } catch (error) {
      console.error("Error updating application:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid update data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "Failed to update application",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async delete(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const success = await ApplicationService.delete(id);
      
      if (!success) {
        return res.status(404).json({
          success: false,
          message: "Application not found"
        });
      }

      res.json({
        success: true,
        message: "Application deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting application:", error);
      res.status(500).json({
        success: false,
        message: "Failed to delete application",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async getRecent(req: Request, res: Response) {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const applications = await ApplicationService.getRecentApplications(limit);
      
      res.json({
        success: true,
        data: applications
      });
    } catch (error) {
      console.error("Error fetching recent applications:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch recent applications",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }
}