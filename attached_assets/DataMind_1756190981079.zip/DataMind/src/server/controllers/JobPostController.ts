import { Request, Response } from "express";
import { JobPostService } from "../services/JobPostService";
import { JobPostModel } from "../models/JobPost";
import { z } from "zod";

export class JobPostController {
  static async getAll(req: Request, res: Response) {
    try {
      const query = req.query;
      
      // Parse and validate query parameters
      const filters = {
        query: query.q as string,
        location: query.location as string,
        type: query.type as string,
        skills: query.skills ? (Array.isArray(query.skills) ? query.skills as string[] : [query.skills as string]) : undefined,
        page: query.page ? parseInt(query.page as string) : 1,
        limit: query.limit ? parseInt(query.limit as string) : 10
      };

      const result = await JobPostService.findAll(filters);
      
      res.json({
        success: true,
        data: result.data,
        pagination: {
          page: result.page,
          limit: filters.limit,
          total: result.total,
          totalPages: result.totalPages
        }
      });
    } catch (error) {
      console.error("Error fetching job posts:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch job posts",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async getById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      
      if (!id) {
        return res.status(400).json({
          success: false,
          message: "Job post ID is required"
        });
      }

      const job = await JobPostService.findById(id);
      
      if (!job) {
        return res.status(404).json({
          success: false,
          message: "Job post not found"
        });
      }

      // Get applications count for this job
      const applicationsCount = await JobPostService.getApplicationsCount(id);

      res.json({
        success: true,
        data: {
          ...job,
          applicationsCount
        }
      });
    } catch (error) {
      console.error("Error fetching job post:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch job post",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async create(req: Request, res: Response) {
    try {
      const jobData = JobPostModel.validateInsert(req.body);
      const job = await JobPostService.create(jobData);
      
      res.status(201).json({
        success: true,
        data: job,
        message: "Job post created successfully"
      });
    } catch (error) {
      console.error("Error creating job post:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid job data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "Failed to create job post",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async update(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const updateData = JobPostModel.validateUpdate(req.body);
      
      const job = await JobPostService.update(id, updateData);
      
      if (!job) {
        return res.status(404).json({
          success: false,
          message: "Job post not found"
        });
      }

      res.json({
        success: true,
        data: job,
        message: "Job post updated successfully"
      });
    } catch (error) {
      console.error("Error updating job post:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Invalid update data",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "Failed to update job post",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async delete(req: Request, res: Response) {
    try {
      const { id } = req.params;
      
      const success = await JobPostService.delete(id);
      
      if (!success) {
        return res.status(404).json({
          success: false,
          message: "Job post not found"
        });
      }

      res.json({
        success: true,
        message: "Job post deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting job post:", error);
      res.status(500).json({
        success: false,
        message: "Failed to delete job post",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }

  static async getFeatured(req: Request, res: Response) {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 6;
      const jobs = await JobPostService.getFeatured(limit);
      
      res.json({
        success: true,
        data: jobs
      });
    } catch (error) {
      console.error("Error fetching featured job posts:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch featured job posts",
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  }
}