import { Router } from "express";
import jobPostRoutes from "./jobPostRoutes";
import careerArticleRoutes from "./careerArticleRoutes";
import applicationRoutes from "./applicationRoutes";

const router = Router();

// Mount route modules
router.use("/jobs", jobPostRoutes);
router.use("/articles", careerArticleRoutes);
router.use("/applications", applicationRoutes);

// Health check endpoint
router.get("/health", (req, res) => {
  res.json({
    success: true,
    message: "CareerHub API is running",
    timestamp: new Date().toISOString(),
    version: "2.0.0"
  });
});

export default router;