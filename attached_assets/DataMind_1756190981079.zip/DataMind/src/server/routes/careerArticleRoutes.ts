import { Router } from "express";
import { CareerArticleController } from "../controllers/CareerArticleController";
import { asyncHandler } from "../middleware/errorHandler";

const router = Router();

// GET /api/articles - Get all career articles with filtering
router.get("/", asyncHandler(CareerArticleController.getAll));

// GET /api/articles/featured - Get featured articles
router.get("/featured", asyncHandler(CareerArticleController.getFeatured));

// GET /api/articles/categories - Get all categories
router.get("/categories", asyncHandler(CareerArticleController.getCategories));

// GET /api/articles/:id - Get article by ID
router.get("/:id", asyncHandler(CareerArticleController.getById));

// GET /api/articles/slug/:slug - Get article by slug
router.get("/slug/:slug", asyncHandler(CareerArticleController.getBySlug));

// POST /api/articles - Create new article
router.post("/", asyncHandler(CareerArticleController.create));

// PUT /api/articles/:id - Update article
router.put("/:id", asyncHandler(CareerArticleController.update));

// DELETE /api/articles/:id - Delete article (soft delete)
router.delete("/:id", asyncHandler(CareerArticleController.delete));

export default router;