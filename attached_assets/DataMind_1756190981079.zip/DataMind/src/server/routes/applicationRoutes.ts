import { Router } from "express";
import { ApplicationController } from "../controllers/ApplicationController";
import { asyncHandler } from "../middleware/errorHandler";
import { uploadApplicationFiles, handleUploadError } from "../middleware/upload";

const router = Router();

// GET /api/applications - Get all applications with filtering
router.get("/", asyncHandler(ApplicationController.getAll));

// GET /api/applications/recent - Get recent applications
router.get("/recent", asyncHandler(ApplicationController.getRecent));

// GET /api/applications/:id - Get application by ID
router.get("/:id", asyncHandler(ApplicationController.getById));

// POST /api/applications - Submit new application with file uploads
router.post("/", 
  uploadApplicationFiles, 
  handleUploadError,
  asyncHandler(ApplicationController.create)
);

// PUT /api/applications/:id - Update application
router.put("/:id", asyncHandler(ApplicationController.update));

// DELETE /api/applications/:id - Delete application
router.delete("/:id", asyncHandler(ApplicationController.delete));

export default router;