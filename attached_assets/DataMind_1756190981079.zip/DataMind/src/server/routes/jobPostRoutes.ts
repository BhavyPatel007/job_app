import { Router } from "express";
import { JobPostController } from "../controllers/JobPostController";
import { asyncHandler } from "../middleware/errorHandler";

const router = Router();

// GET /api/jobs - Get all job posts with filtering
router.get("/", asyncHandler(JobPostController.getAll));

// GET /api/jobs/featured - Get featured job posts
router.get("/featured", asyncHandler(JobPostController.getFeatured));

// GET /api/jobs/:id - Get job post by ID
router.get("/:id", asyncHandler(JobPostController.getById));

// POST /api/jobs - Create new job post
router.post("/", asyncHandler(JobPostController.create));

// PUT /api/jobs/:id - Update job post
router.put("/:id", asyncHandler(JobPostController.update));

// DELETE /api/jobs/:id - Delete job post (soft delete)
router.delete("/:id", asyncHandler(JobPostController.delete));

export default router;