# Overview

CareerHub is a professional full-stack job board application built with React, Express.js, and PostgreSQL. The application allows users to browse job postings, read career articles, and submit job applications with file uploads (resumes and certificates). It features a modern UI built with shadcn/ui components and Tailwind CSS, providing both job seekers and employers with a comprehensive platform for career opportunities.

## Recent Updates (January 26, 2025)
✅ Professional code restructure completed with enterprise-level architecture
✅ MVC pattern implemented with controllers, services, models, and middleware
✅ Dynamic folder organization with proper separation of concerns  
✅ Database integration with Drizzle ORM and PostgreSQL
✅ File upload system for resumes and certificates (PDF, DOC, DOCX, JPG, PNG)
✅ Comprehensive error handling and validation throughout the application
✅ RESTful API design with proper HTTP status codes and structured responses

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The client-side is built with React and TypeScript, using a component-based architecture:

- **UI Framework**: React with TypeScript for type safety
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for fast development and optimized production builds

The application follows a page-based routing structure with dedicated components for jobs, articles, and application forms. The UI components are built using Radix UI primitives wrapped with custom styling.

## Backend Architecture

The server-side follows a professional MVC (Model-View-Controller) architecture with enterprise-level patterns:

### Core Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules and strict type checking
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Design Pattern**: Clean Architecture with separation of concerns

### Folder Structure
```
src/server/
├── config/           # Database and environment configuration
├── controllers/      # Request/Response handling and HTTP logic
├── services/         # Business logic and data processing
├── models/          # Data validation and schema definitions
├── middleware/      # Cross-cutting concerns (auth, validation, error handling)
└── routes/          # API endpoint definitions and route organization
```

### Key Components
- **Controllers**: Handle HTTP requests, validate input, and coordinate responses
- **Services**: Encapsulate business logic and database operations
- **Models**: Define data structures and validation schemas using Zod
- **Middleware**: Handle file uploads, error management, and request validation
- **Routes**: Modular route organization with proper REST conventions

### File Upload System
- **Multer Integration**: Secure file handling with type and size validation
- **Supported Types**: PDF, DOC, DOCX, JPG, JPEG, PNG (5MB max per file)
- **Storage**: Local file system with unique filename generation
- **Security**: Comprehensive file validation and error handling

### Error Handling
- **Global Error Handler**: Centralized error processing with proper HTTP status codes
- **Custom Error Classes**: Structured error responses with development/production modes
- **Async Wrapper**: Automatic error catching for async route handlers
- **Validation**: Zod-based request validation with detailed error messages

## Database Design

PostgreSQL database with Drizzle ORM provides the data persistence layer:

- **Users**: Authentication and user management
- **Job Posts**: Job listings with company information, requirements, and skills
- **Career Articles**: Content management for career advice and industry insights
- **Applications**: Job application tracking with file upload support

The schema uses UUID primary keys and includes proper relationships between entities. Database migrations are managed through Drizzle Kit.

## Authentication & Session Management

The application uses session-based authentication:

- **Session Store**: PostgreSQL-backed sessions using connect-pg-simple
- **Security**: Secure cookie configuration with proper domain and path settings
- **User Management**: Username/password authentication with hashed passwords

## File Upload System

Multer handles file uploads with security restrictions:

- **Supported Types**: PDF, DOC, DOCX, JPG, JPEG, PNG
- **Size Limits**: 5MB maximum file size
- **Storage**: Local file system with configurable upload directory
- **Validation**: File type and size validation on both client and server

## External Dependencies

### Database
- **Neon Database**: PostgreSQL-compatible serverless database with connection pooling
- **Drizzle ORM**: Type-safe database operations and schema management

### UI/UX Libraries
- **Radix UI**: Accessible, unstyled UI primitives for complex components
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library with Radix UI and Tailwind

### Development Tools
- **Vite**: Build tool and development server with HMR
- **TypeScript**: Static type checking and enhanced developer experience
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form validation and state management
- **Zod**: Runtime type validation and schema parsing

### Production Infrastructure
- **Replit**: Development environment with integrated database provisioning
- **Node.js**: Runtime environment for server-side JavaScript
- **Express.js**: Web application framework for Node.js